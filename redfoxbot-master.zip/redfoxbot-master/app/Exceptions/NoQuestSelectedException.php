<?php
/**
 * Created by PhpStorm.
 * User: akeinhell
 * Date: 10.04.16
 * Time: 15:35.
 */

namespace App\Exceptions;

class NoQuestSelectedException extends \Exception
{
}
