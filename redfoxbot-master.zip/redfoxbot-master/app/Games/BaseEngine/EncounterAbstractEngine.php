<?php
/**
 * Created by PhpStorm.
 * User: akeinhell
 * Date: 03.05.2016
 * Time: 5:45.
 */

namespace App\Games\BaseEngine;

abstract class EncounterAbstractEngine extends AbstractGameEngine
{
}
