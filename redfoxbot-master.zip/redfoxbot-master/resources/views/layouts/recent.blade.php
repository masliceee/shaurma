<section class="box recent-posts">
    <header>
        <h2>Recent Posts</h2>
    </header>
    <ul>
        <li><a href="#">Lorem ipsum dolor</a></li>
        <li><a href="#">Feugiat nisl aliquam</a></li>
        <li><a href="#">Sed dolore magna</a></li>
        <li><a href="#">Malesuada commodo</a></li>
        <li><a href="#">Ipsum metus nullam</a></li>
    </ul>
</section>