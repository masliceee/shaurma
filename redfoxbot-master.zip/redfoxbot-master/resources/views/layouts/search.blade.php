<!-- Search -->
<section class="box search">
    <form method="post" action="#">
        <input type="text" class="text" name="search" placeholder="Search"/>
    </form>
</section>
