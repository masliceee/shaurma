<section class="box text-style1">
    <div class="inner">
        <p>
            <strong>Striped:</strong> A free and fully responsive HTML5 site
            template designed by <a href="http://n33.co/">AJ</a> for <a href="http://html5up.net/">HTML5 UP</a>
        </p>
    </div>
</section>