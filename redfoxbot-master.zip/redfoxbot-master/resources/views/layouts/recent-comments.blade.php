<section class="box recent-comments">
    <header>
        <h2>Recent Comments</h2>
    </header>
    <ul>
        <li>case on <a href="#">Lorem ipsum dolor</a></li>
        <li>molly on <a href="#">Sed dolore magna</a></li>
        <li>case on <a href="#">Sed dolore magna</a></li>
    </ul>
</section>