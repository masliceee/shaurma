@extends('layouts.main')

@section('title')
   404
@endsection

@section('menu')
@endsection

@section('content')
    Ничего не найдено
@endsection