@extends('layouts.main')

@section('title', 'Поддержка проекта')

@section('content')
    
@endsection